import Carrousel from '../components/Carrousel'
import ComidasHome from '../components/ComidasHome';

function Home(){
    return(
    <div>
        <Carrousel />
        <ComidasHome />   
    </div>
    )
}

export default Home;